class campp:
    def __init__(self,Camp_ID,Camp_Name,Camp_No,Title,contact,Tent_No,address):
        self.Camp_ID=Camp_ID
        self.Camp_Name=Camp_Name
        self.Camp_No=Camp_No
        self.Title=Title
        self.contact=contact
        self.Tent_No=Tent_No
        self.address=address

    def set_Camp_ID(self,Camp_ID):
        self.Camp_ID=Camp_ID

    def get_Camp_ID(self):
        return self.Camp_ID

    def set_Camp_Name(self,Camp_Name):
        self.Camp_Name=Camp_Name

    def get_Camp_Name(self):
        return self.Camp_Name

    def set_Camp_No(self,Camp_No):
        self.Camp_No=Camp_No

    def get_Camp_No(self):
        return self.Camp_No

    def set_Title(self,Title):
        self.Title=Title

    def get_Title(self):
        return self.Title

    def set_contact(self,contact):
        self.contact=contact

    def get_contact(self):
        return self.contact

    def set_Tent_No(self,Tent_No):
        self.Tent_No=Tent_No

    def get_Tent_No(self):
        return self.Tent_No

    def set_address(self,address):
        self.address=address

    def get_address(self):
        return self.address















