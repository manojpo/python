class info:
    def __init__(self,Citizenship_No,name,Camp_ID,gender,contact,height,post):
        self.Citizenship_No=Citizenship_No
        self.name=name
        self.Camp_ID=Camp_ID
        self.gender=gender
        self.contact=contact
        self.height=height
        self.post=post

    def set_Citizenship_No(self,Citizenship_No):
        self.Citizenship_No=Citizenship_No

    def get_Citizenship_No(self):
        return self.Citizenship_No

    def set_name(self,name):
        self.name_No=name

    def get_name(self):
        return self.name

    def set_Camp_ID(self, Camp_ID):
        self.Camp_ID = Camp_ID

    def get_Camp_ID(self):
        return self.Camp_ID

    def set_gender(self,gender):
        self.gender=gender

    def get_gender(self):
        return self.gender

    def set_contact(self,contact):
        self.contact=contact

    def get_contact(self):
        return self.contact

    def set_height(self,height):
        self.height_No=height

    def get_height(self):
        return self.height

    def set_post(self,post):
        self.post=post

    def get_post(self):
        return self.post
