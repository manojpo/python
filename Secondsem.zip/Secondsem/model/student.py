class Student:
    def __init__(self,id,name):
        self.id=id
        self.name=name

    def set_id(self,id):
        self.id=id


    def get_id(self):
        return self.id

    def set_name(self,name):
        self.name=name

    def get_name(self):
        return self.name






