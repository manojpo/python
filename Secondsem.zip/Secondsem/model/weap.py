class weap:
    def __init__(self,Weapon_type,Weapon_Name,Weapon_No,Bullet_qty):
        self.Weapon_type=Weapon_type
        self.Weapon_Name=Weapon_Name
        self.Weapon_No=Weapon_No
        self.Bullet_qty=Bullet_qty


    def set_Weapon_type(self,Weapon_type):
        self.Weapon_type=Weapon_type


    def get_Weapon_type(self):
        return self.Weapon_type

    def set_Weapon_Name(self,Weapon_Name):
        self.Camp_Weapon=Weapon_Name

    def get_Weapon_Name(self):
        return self.Weapon_Name

    def set_Weapon_No(self,Weapon_No):
        self.Weapon_No=Weapon_No

    def get_Weapon_No(self):
        return self.Weapon_No

    def set_Bullet_qty(self,Bullet_qty):
        self.Bullet_qty=Bullet_qty

    def get_Bullet_qty(self):
        return self.Bullet_qty

